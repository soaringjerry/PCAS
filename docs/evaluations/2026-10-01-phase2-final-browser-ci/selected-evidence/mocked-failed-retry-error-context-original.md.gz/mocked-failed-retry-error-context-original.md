# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: phase2_manual.spec.ts >> failed manual run retries with complete original recipient and unchanged prompt
- Location: tests/phase2_manual.spec.ts:195:1

# Error details

```
Error: expect(received).toMatchObject(expected)

- Expected  - 6
+ Received  + 0

  Object {
    "agentId": "manual",
    "kind": "draft",
    "manualRecipient": Object {
-     "channel": "manual",
-     "model": "synthetic-model",
-     "principal_id": "manual",
-     "protocol": "openai",
      "provider": "writer",
-     "role": "manual",
-     "route_fingerprint": "synthetic-route-A",
    },
    "prompt": "原用户请求：请写一份自然的合成邀请",
    "type": "requestRun",
  }
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner [ref=e4]:
    - link "回到大厅" [ref=e5] [cursor=pointer]:
      - /url: /
      - text: PCAS
    - generic [aria-hidden] [ref=e6]: /
    - generic [ref=e7]: 合成读书会验收
    - navigation "导航" [ref=e8]:
      - button "搜索" [ref=e9] [cursor=pointer]:
        - generic [ref=e14]: Ctrl K
      - link "资料库" [ref=e15] [cursor=pointer]:
        - /url: /library
      - link "设置" [ref=e19] [cursor=pointer]:
        - /url: /settings
  - main [ref=e24]:
    - generic [ref=e25]:
      - link "大厅" [ref=e27] [cursor=pointer]:
        - /url: /
      - generic [ref=e30]:
        - button "做完了" [ref=e31] [cursor=pointer]
        - textbox "标题" [ref=e32]: 合成读书会验收
        - button [aria-hidden] [ref=e33] [cursor=pointer]
      - group "这件事的情况，点一项就跟秘书说怎么改" [ref=e37]:
        - button "待办" [ref=e38] [cursor=pointer]
        - button "定个截止时间" [ref=e39] [cursor=pointer]
        - button "加个提醒" [ref=e40] [cursor=pointer]
      - textbox "说明" [ref=e41]:
        - /placeholder: 加点说明（点这里直接写）
        - text: 原事项说明：合成读书会，只用于验收
      - generic [ref=e42]:
        - generic [ref=e43]: 子任务
        - textbox "加一步" [ref=e48]
      - button "新建文档" [ref=e50] [cursor=pointer]
      - generic [ref=e52]:
        - generic [ref=e53]: 动态
        - button "手动转交" [ref=e55] [cursor=pointer]
        - list [ref=e56]:
          - listitem [ref=e57]:
            - generic [ref=e58]:
              - generic "手动交接" [ref=e59]: 副手
              - generic "synthetic-failure" [ref=e60]: 没做成：出了点问题
              - button "重试" [ref=e61] [cursor=pointer]
              - button "换 友好接收者 writer 重试" [ref=e62] [cursor=pointer]
              - generic [ref=e63]: 7 小时前
            - button "选择接收者，建立新请求" [ref=e66] [cursor=pointer]
      - region "秘书" [ref=e67]:
        - generic [ref=e68]:
          - button "结束这次对话" [ref=e69] [cursor=pointer]
          - list [ref=e73]:
            - listitem [ref=e74]:
              - paragraph [ref=e75]: 独立 owner 原文：先保留我的原话，再整理邀请
              - paragraph [ref=e76]: 已保留合成原文
        - generic [ref=e78]:
          - textbox "跟秘书说" [ref=e79]:
            - /placeholder: 关于这件事，说一句
          - button "发送" [disabled] [ref=e80]
```

# Test source

```ts
  100 |   await expect.poll(() => backend.commands.length).toBe(1)
  101 |   expect(backend.commands[0]).toMatchObject({ type: 'requestRun', agentId: 'manual', thingId, kind: 'ask', prompt: '新的自然请求：请写亲切一点', manualRecipient: { provider: 'other' } })
  102 |   expect(Object.keys(backend.commands[0].manualRecipient!)).toEqual(['provider'])
  103 |   expect(backend.commands[0].id).not.toBe(runId)
  104 |   expect(JSON.stringify(backend.commands[0])).not.toMatch(/fingerprint|scope/)
  105 |   expect(backend.state.runs[0].prompt).toBe(prompt)
  106 |   await assertClean(page, backend)
  107 | })
  108 | 
  109 | test('every preview and copy obtains a fresh no-store GET; external receipt stays unknown', async ({ page }) => {
  110 |   const backend = await mock(page); await open(page)
  111 |   await preview(page).click(); await expect(shownPackage(page)).toContainText('FRESH_PACKAGE_1'); await expect(shownPackage(page)).toHaveText(backend.packages[0])
  112 |   await expect(handoff(page)).toContainText(/无法确认.*(?:收到|接收)|外部接收.*未知/)
  113 |   await page.getByRole('button', { name: '收起', exact: true }).click()
  114 |   await preview(page).click(); await expect(shownPackage(page)).toContainText('FRESH_PACKAGE_2'); await expect(shownPackage(page)).toHaveText(backend.packages[1])
  115 |   await copy(page).click(); await expect.poll(() => backend.packages.length).toBe(3); await expect.poll(() => copied(page)).toEqual([backend.packages[2]])
  116 |   await copy(page).click(); await expect.poll(() => backend.packages.length).toBe(4); await expect.poll(() => copied(page)).toEqual([backend.packages[2], backend.packages[3]])
  117 |   expect(backend.packages).toHaveLength(4)
  118 |   const requests = await page.evaluate(() => (window as unknown as { phase2Fetches: { path: string; cache?: string; method?: string }[] }).phase2Fetches.filter(f => f.path.endsWith('/package')))
  119 |   expect(requests).toHaveLength(4)
  120 |   for (const request of requests) expect(request).toMatchObject({ method: 'GET', cache: 'no-store' })
  121 |   await expect(handoff(page)).not.toContainText(/对方已收到|外部已收到|接收者已收到/)
  122 |   await assertClean(page, backend)
  123 | })
  124 | 
  125 | const changes = ['revision', 'stale', 'route', 'status', 'authorization'] as const
  126 | function change(backend: Awaited<ReturnType<typeof mock>>, mode: typeof changes[number]) {
  127 |   backend.state = structuredClone(backend.state)
  128 |   if (mode === 'revision' || mode === 'authorization') backend.state.revision++
  129 |   if (mode === 'stale') backend.state.runs[0].staleContext = true
  130 |   if (mode === 'route') backend.state.runs[0].contextTask!.recipient.route_fingerprint = 'synthetic-route-B'
  131 |   if (mode === 'status') backend.state.runs[0].status = 'done'
  132 |   if (mode === 'authorization') backend.state.agents[0].enabled = false
  133 |   backend.state.tasks[0].title = `已同步变化 ${mode}`
  134 | }
  135 | async function waitChange(page: Page, mode: string) { await expect(page.getByRole('textbox', { name: '标题', exact: true })).toHaveValue(`已同步变化 ${mode}`, { timeout: 7000 }) }
  136 | for (const mode of changes) {
  137 |   test(`existing preview clears after ${mode} changes`, async ({ page }) => {
  138 |     const backend = await mock(page); await open(page); await preview(page).click(); await expect(shownPackage(page)).toBeVisible()
  139 |     change(backend, mode); await waitChange(page, mode)
  140 |     await expect(shownPackage(page)).toHaveCount(0); expect(await copied(page)).toEqual([])
  141 |     await assertClean(page, backend)
  142 |   })
  143 |   for (const operation of ['preview', 'copy'] as const) test(`late ${operation} package is rejected after ${mode} changes`, async ({ page }) => {
  144 |     const backend = await mock(page); await open(page); const release = backend.hold()
  145 |     const response = page.waitForResponse(r => new URL(r.url()).pathname.endsWith('/package'))
  146 |     try {
  147 |       await (operation === 'preview' ? preview(page) : copy(page)).click(); await expect.poll(() => backend.packages.length).toBe(1)
  148 |       change(backend, mode); await waitChange(page, mode)
  149 |     } finally { release() }
  150 |     await (await response).finished()
  151 |     await page.evaluate(() => new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))))
  152 |     if (mode !== 'stale' && mode !== 'status') await expect(copy(page)).toBeEnabled()
  153 |     await expect(shownPackage(page)).toHaveCount(0); expect(await copied(page)).toEqual([])
  154 |     await assertClean(page, backend)
  155 |   })
  156 | }
  157 | 
  158 | for (const malformed of ['wrong run', 'undelivered', 'wrong manifest provider', 'wrong manifest route'] as const) test(`rejects ${malformed} package`, async ({ page }) => {
  159 |   const backend = await mock(page)
  160 |   backend.responsePatch = pkg => {
  161 |     if (malformed === 'wrong run') pkg.run_id = 'another-run'
  162 |     if (malformed === 'undelivered') delete pkg.attempt.delivered_at
  163 |     if (malformed === 'wrong manifest provider') pkg.attempt.manifest.recipient.provider = 'other'
  164 |     if (malformed === 'wrong manifest route') pkg.attempt.manifest.recipient.route_fingerprint = 'synthetic-mismatched-route'
  165 |   }
  166 |   await open(page); await preview(page).click(); await expect(copy(page)).toBeEnabled()
  167 |   await expect(shownPackage(page)).toHaveCount(0)
  168 |   await expect(page.getByRole('button', { name: '向原接收者重新生成' })).toBeVisible()
  169 |   expect(await copied(page)).toEqual([]); await assertClean(page, backend)
  170 | })
  171 | 
  172 | test('package failure clears old preview and regenerates with the complete original recipient', async ({ page }) => {
  173 |   const backend = await mock(page); await open(page); await preview(page).click(); await expect(shownPackage(page)).toBeVisible()
  174 |   backend.rejectPackage = true; await copy(page).click()
  175 |   await expect(shownPackage(page)).toHaveCount(0)
  176 |   await page.getByRole('button', { name: '向原接收者重新生成' }).click()
  177 |   await expect.poll(() => backend.commands.length).toBe(1)
  178 |   expect(backend.commands[0]).toMatchObject({ type: 'requestRun', prompt, kind: 'draft', manualRecipient: recipient })
  179 |   expect(backend.commands[0].id).not.toBe(runId); expect(await copied(page)).toEqual([])
  180 |   await assertClean(page, backend)
  181 | })
  182 | 
  183 | test('paste rejection clears preview and offers regeneration without claiming save', async ({ page }) => {
  184 |   const backend = await mock(page); backend.rejectPaste = true; await open(page)
  185 |   await preview(page).click(); await expect(shownPackage(page)).toBeVisible()
  186 |   await page.getByRole('textbox', { name: '贴回回答' }).fill('合成外部回答')
  187 |   await page.getByRole('button', { name: '保存并加入这件事' }).click()
  188 |   await expect(shownPackage(page)).toHaveCount(0)
  189 |   await expect(handoff(page)).toContainText('回答没有保存或加入这件事')
  190 |   await expect(page.getByRole('button', { name: '向原接收者重新生成' })).toBeVisible()
  191 |   expect(backend.commands).toHaveLength(1); expect(backend.commands[0]).toMatchObject({ type: 'pasteRunResult', id: runId, output: '合成外部回答' })
  192 |   await assertClean(page, backend)
  193 | })
  194 | 
  195 | test('failed manual run retries with complete original recipient and unchanged prompt', async ({ page }) => {
  196 |   const state = workspace(); state.runs[0].status = 'failed'; state.runs[0].error = 'synthetic-failure'
  197 |   const backend = await mock(page, state); await page.goto(`/t/${thingId}`)
  198 |   await page.getByRole('button', { name: '重试', exact: true }).click()
  199 |   await expect.poll(() => backend.commands.length).toBe(1)
> 200 |   expect(backend.commands[0]).toMatchObject({ type: 'requestRun', agentId: 'manual', prompt, kind: 'draft', manualRecipient: recipient })
      |                               ^ Error: expect(received).toMatchObject(expected)
  201 |   expect(backend.commands[0].id).not.toBe(runId); await assertClean(page, backend)
  202 | })
  203 | 
  204 | test('changing recipient creates a new run and preserves the old run and owner input', async ({ page }) => {
  205 |   const backend = await mock(page); const old = structuredClone(backend.state.runs[0]); await open(page)
  206 |   await page.getByRole('button', { name: '换接收者，建立新请求' }).click()
  207 |   await expect(page.getByRole('textbox', { name: '本次转交请求' })).toHaveValue(prompt)
  208 |   await page.getByRole('button', { name: '转交接收者' }).click(); await page.getByRole('option', { name: /友好接收者 other/ }).click()
  209 |   await page.getByRole('button', { name: '建立转交请求' }).click(); await expect.poll(() => backend.commands.length).toBe(1)
  210 |   expect(backend.commands[0]).toMatchObject({ type: 'requestRun', prompt, kind: 'draft', manualRecipient: { provider: 'other' } })
  211 |   expect(backend.commands[0].id).not.toBe(runId); expect(backend.state.runs[0]).toEqual(old); await assertClean(page, backend)
  212 | })
  213 | 
  214 | test('desktop and 390px browser views preserve content without horizontal overflow', async ({ page }, info) => {
  215 |   const backend = await mock(page); await page.setViewportSize({ width: 1280, height: 1000 }); await open(page)
  216 |   await preview(page).click(); await expect(shownPackage(page)).toBeVisible()
  217 |   await page.screenshot({ path: info.outputPath('phase2-manual-desktop.png'), fullPage: true })
  218 |   await page.setViewportSize({ width: 390, height: 1000 })
  219 |   expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(390)
  220 |   await page.screenshot({ path: info.outputPath('phase2-manual-390px.png'), fullPage: true })
  221 |   await page.getByRole('button', { name: '换接收者，建立新请求' }).click()
  222 |   await page.getByRole('button', { name: '转交接收者' }).click(); await page.getByRole('option', { name: /友好接收者 other/ }).click()
  223 |   await expect(page.getByRole('textbox', { name: '本次转交请求' })).toHaveValue(prompt)
  224 |   expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(390)
  225 |   await page.screenshot({ path: info.outputPath('phase2-manual-selection-390px.png'), fullPage: true })
  226 |   const submit = page.getByRole('button', { name: '建立转交请求' })
  227 |   await expect(submit).toBeEnabled(); await assertClean(page, backend)
  228 |   await submit.scrollIntoViewIfNeeded()
  229 |   const box = await submit.boundingBox()
  230 |   expect(box).not.toBeNull()
  231 |   const viewport = await page.evaluate(() => ({ width: innerWidth, height: innerHeight }))
  232 |   expect(box!.x).toBeGreaterThanOrEqual(0)
  233 |   expect(box!.y).toBeGreaterThanOrEqual(0)
  234 |   expect(box!.x + box!.width).toBeLessThanOrEqual(viewport.width)
  235 |   expect(box!.y + box!.height).toBeLessThanOrEqual(viewport.height)
  236 |   // Check the center and four edge midpoints inside the pill-shaped button.
  237 |   const uncovered = await submit.evaluate(button => {
  238 |     const rect = button.getBoundingClientRect()
  239 |     const cx = rect.x + rect.width / 2, cy = rect.y + rect.height / 2
  240 |     return [[cx, cy], [cx, rect.y + 2], [cx, rect.bottom - 2], [rect.x + 2, cy], [rect.right - 2, cy]]
  241 |       .every(([x, y]) => { const hit = document.elementFromPoint(x, y); return hit !== null && (hit === button || button.contains(hit)) })
  242 |   })
  243 |   expect(uncovered).toBe(true)
  244 |   await page.screenshot({ path: info.outputPath('phase2-manual-selection-390px-operable.png') })
  245 |   await submit.click()
  246 |   await expect.poll(() => backend.commands.length).toBe(1)
  247 |   expect(backend.commands[0]).toMatchObject({ type: 'requestRun', prompt, kind: 'draft', manualRecipient: { provider: 'other' } })
  248 |   expect(backend.commands[0].id).not.toBe(runId)
  249 |   expect(backend.state.runs[0].prompt).toBe(prompt)
  250 |   expect(backend.state.runs[0].manualRecipient).toEqual(recipient)
  251 |   await assertClean(page, backend)
  252 | })
  253 | 
```