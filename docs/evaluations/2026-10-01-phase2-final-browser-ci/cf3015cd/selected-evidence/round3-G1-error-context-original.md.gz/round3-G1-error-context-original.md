# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: golden.spec.ts >> G1 一句话安排：时间、项目、提醒、刷新与撤销
- Location: tests/golden.spec.ts:25:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.hall-task').filter({ hasText: '和张三对方案-1790870655320' })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('.hall-task').filter({ hasText: '和张三对方案-1790870655320' }) with timeout 5000ms
  - waiting for locator('.hall-task').filter({ hasText: '和张三对方案-1790870655320' })

```

```yaml
- banner:
  - link "回到大厅":
    - /url: /
    - text: PCAS
  - navigation "导航":
    - button "搜索": 搜索 Ctrl K
    - link "资料库":
      - /url: /library
    - link "设置":
      - /url: /settings
- main:
  - region "今天":
    - heading "今天" [level=1]
    - text: 10月2日星期五
    - heading "按时间" [level=2]
    - separator "现在 00:04"
    - paragraph: 今天没有定了时间的事。
    - paragraph: 今天没有要你动手的事。
  - region "秘书":
    - button "结束这次对话"
    - list:
      - listitem:
        - paragraph: 周五下午三点和张三对方案，算在 A 项目里
        - paragraph: 安排好了。
        - list:
          - listitem:
            - text: 已建：10 月 9 日 15:00
            - link "和张三对方案-1790870655320":
              - /url: /t/66f68427-8029-418d-8252-1d42fd39002f
            - text: · A 项目 · 14:30 提醒
            - button "改"
            - button "撤销"
    - textbox "跟秘书说":
      - /placeholder: 说一句：记事、问事、改安排都行
    - button "发送" [disabled]
  - region "你不在的时候":
    - button "你不在的时候：1 件 有新的": 你不在的时候：1 件
  - region "项目":
    - heading "项目" [level=2]
    - list:
      - listitem: A 进行中 · 1 件在做 还没有进展记录 下一步：和张三对方案-1790870655320
  - region "想法":
    - heading "想法" [level=2]
    - paragraph: 还没有想法。在导办台随口说一句「要不……」就会记到这里。
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test'
  2   | import { createECDH, randomBytes } from 'node:crypto'
  3   | import { command, events, evidence, fixture, input, localTime, login, nextWeekday, reply, say, snapshot, utc } from './support/real'
  4   | 
  5   | test.use({ timezoneId: 'Asia/Shanghai', viewport: { width: 1440, height: 1000 } })
  6   | test.beforeEach(async ({ page }) => {
  7   |   await login(page)
  8   |   await command(page, { type: 'updateSettings', patch: { timezone: 'Asia/Shanghai', followUps: true } })
  9   | })
  10  | test.afterEach(async ({ page }, info) => { await evidence(page, info) })
  11  | 
  12  | const schedule = '周五下午三点和张三对方案，算在 A 项目里'
  13  | async function arrange(page: Parameters<typeof say>[0], title: string) {
  14  |   let state = await snapshot(page)
  15  |   if (!state.projects.some(p => p.name === 'A')) state = await command(page, { type: 'addProject', name: 'A' })
  16  |   const due = nextWeekday(5, 15)
  17  |   await fixture(page, [reply(schedule, [{ op: 'create_task', title, due, project: 'P1', remind: null }])])
  18  |   const response = await say(page, schedule)
  19  |   const task = response.state.tasks.find((t: { id: string }) => t.id === response.turn.receipts[0].thingId)
  20  |   expect(task).toMatchObject({ due: utc(due), projectId: state.projects.find(p => p.name === 'A')!.id })
  21  |   expect(task.triggers[0]).toMatchObject({ offset: '-30m', nextAt: utc(due.replace('15:00', '14:30')) })
  22  |   return task
  23  | }
  24  | 
  25  | test('G1 一句话安排：时间、项目、提醒、刷新与撤销', async ({ page }) => {
  26  |   const task = await arrange(page, `和张三对方案-${Date.now()}`)
  27  |   const receipt = page.locator('.sec-receipt').filter({ hasText: task.title })
  28  |   await expect(receipt).toContainText('15:00')
  29  |   await expect(receipt).toContainText('A 项目')
  30  |   await expect(receipt).toContainText('14:30 提醒')
> 31  |   await expect(page.locator('.hall-task').filter({ hasText: task.title })).toBeVisible()
      |                                                                            ^ Error: expect(locator).toBeVisible() failed
  32  |   await evidence(page, test.info(), 'arranged')
  33  |   await page.reload()
  34  |   await expect(receipt).toBeVisible()
  35  |   await expect(page.locator('.hall-task').filter({ hasText: task.title })).toBeVisible()
  36  |   await receipt.getByRole('button', { name: '撤销', exact: true }).click()
  37  |   await expect(receipt).toContainText('已撤销')
  38  |   expect((await snapshot(page)).tasks.some(t => t.id === task.id)).toBeFalsy()
  39  |   await expect(page.locator('.hall-task').filter({ hasText: task.title })).toHaveCount(0)
  40  | })
  41  | 
  42  | test('G2 边问边记：回复前连续发送，两轮都处理', async ({ page }) => {
  43  |   const title = `交电费-${Date.now()}`
  44  |   await fixture(page, [
  45  |     { ...reply('今天怎么安排比较好', [], { reply: '先处理到期事项。' }), delay: 2500 },
  46  |     reply('顺便记下明天交电费', [{ op: 'create_task', title, due: localTime(1, 9) }]),
  47  |   ])
  48  |   const first = say(page, '今天怎么安排比较好')
  49  |   await expect(page.getByText('正在想…', { exact: true })).toBeVisible()
  50  |   await expect(input(page)).toBeEnabled()
  51  |   const second = await say(page, '顺便记下明天交电费')
  52  |   await first
  53  |   await expect(page.getByText('先处理到期事项。', { exact: true })).toBeVisible()
  54  |   expect(second.turn.receipts[0].op).toBe('create_task')
  55  |   await expect(page.locator('.hall-task').filter({ hasText: title })).toBeVisible()
  56  |   await expect(input(page)).toBeEnabled()
  57  | })
  58  | 
  59  | test('G3 改安排：同一件事改到周一，提醒跟随', async ({ page }) => {
  60  |   const task = await arrange(page, `改期方案-${Date.now()}`)
  61  |   const due = nextWeekday(1, 10)
  62  |   await fixture(page, [reply('改到下周一上午十点', [{ op: 'update', ref: 'R1', set: { due } }])])
  63  |   const response = await say(page, '改到下周一上午十点')
  64  |   expect(response.turn.receipts[0].thingId).toBe(task.id)
  65  |   const changed = response.state.tasks.find((t: { id: string }) => t.id === task.id)
  66  |   expect(changed.due).toBe(utc(due))
  67  |   expect(changed.triggers[0].nextAt).toBe(utc(due.replace('10:00', '09:30')))
  68  |   expect(response.state.tasks.filter((t: { title: string }) => t.title === task.title)).toHaveLength(1)
  69  |   await page.goto(`/t/${task.id}`)
  70  |   await expect(page.locator('.info-line')).toContainText('10:00')
  71  |   await expect(page.locator('.info-line')).toContainText('09:30 提醒')
  72  | })
  73  | 
  74  | async function taskPage(page: Parameters<typeof say>[0], title: string) {
  75  |   const state = await command(page, { type: 'addTask', title })
  76  |   const task = state.tasks.find(t => t.title === title)!
  77  |   await page.goto(`/t/${task.id}`)
  78  |   return task
  79  | }
  80  | const breakdown = reply('拆成三步', [{ op: 'delegate', ref: 'THIS', kind: 'breakdown', prompt: '拆成三步' }])
  81  | 
  82  | test('G4 事项页秘书：自动加入三步、撤销、放回去', async ({ page }) => {
  83  |   const task = await taskPage(page, `准备方案-${Date.now()}`)
  84  |   await fixture(page, [breakdown])
  85  |   await say(page, '拆成三步')
  86  |   const adoption = page.locator('.activity > li').filter({ hasText: '已加入 3 个子任务' })
  87  |   await expect(adoption).toBeVisible({ timeout: 20000 })
  88  |   expect((await snapshot(page)).tasks.find(t => t.id === task.id)!.checklist).toHaveLength(3)
  89  |   await adoption.getByRole('button', { name: '撤销', exact: true }).click()
  90  |   await expect(page.getByRole('button', { name: '加入 3 个子任务', exact: true })).toBeVisible()
  91  |   expect((await snapshot(page)).tasks.find(t => t.id === task.id)!.checklist).toHaveLength(0)
  92  |   await page.getByRole('button', { name: '加入 3 个子任务', exact: true }).click()
  93  |   await expect(adoption).toBeVisible()
  94  |   expect((await snapshot(page)).tasks.find(t => t.id === task.id)!.checklist).toHaveLength(3)
  95  | })
  96  | 
  97  | test('G5 失败恢复：副手首请求报错，原地重试成功', async ({ page }, info) => {
  98  |   const task = await taskPage(page, `失败恢复-${Date.now()}`)
  99  |   await fixture(page, [breakdown, { kind: 'assistant', match: '', status: 503, once: true }])
  100 |   await say(page, '拆成三步')
  101 |   const retry = page.getByRole('button', { name: '重试', exact: true })
  102 |   await expect(retry).toBeVisible({ timeout: 20000 })
  103 |   await expect(page.locator('.activity')).toContainText('没做成：')
  104 |   const failedRuns = (await snapshot(page)).runs.filter(run => run.thingId === task.id)
  105 |   expect(failedRuns).toHaveLength(1)
  106 |   expect(failedRuns[0].status).toBe('failed')
  107 |   const retryResponsePromise = page.waitForResponse(response => new URL(response.url()).pathname === '/v1/workspace/commands' && response.request().postDataJSON()?.type === 'requestRun' && response.request().postDataJSON()?.thingId === task.id)
  108 |   await retry.click()
  109 |   const retryResponse = await retryResponsePromise
  110 |   const retryBody = retryResponse.request().postDataJSON() as Record<string, unknown>
  111 |   expect(retryBody).toMatchObject({ type: 'requestRun', thingId: task.id, agentId: failedRuns[0].agentId, kind: failedRuns[0].kind, prompt: failedRuns[0].prompt, sourceRunId: failedRuns[0].id })
  112 |   expect(retryBody).not.toHaveProperty('manualRecipient')
  113 |   await info.attach('G5-real-retry-request', { body: JSON.stringify({ originalFailedRun: failedRuns[0], actualRequest: retryBody, responseStatus: retryResponse.status() }, null, 2), contentType: 'application/json' })
  114 |   await expect(page.locator('.activity')).toContainText('已加入 3 个子任务', { timeout: 20000 })
  115 |   expect((await events(page)).filter(e => e.kind === 'model' && e.role === 'assistant')).toHaveLength(2)
  116 | })
  117 | 
  118 | test('G6 提醒送达：真实等待一分钟、首页、Web Push、Telegram', async ({ page, context }) => {
  119 |   test.setTimeout(130000)
  120 |   await context.grantPermissions(['notifications'], { origin: process.env.PCAS_TEST_BASE_URL })
  121 |   await page.reload()
  122 |   test.info().annotations.push({ type: 'push-permission', description: await page.evaluate(() => Notification.permission) })
  123 |   await page.evaluate(() => navigator.serviceWorker.ready.then(r => r.active?.state))
  124 |   const key = createECDH('prime256v1'); key.generateKeys()
  125 |   const subscription = { endpoint: 'https://push.pcas.test/push', keys: { p256dh: key.getPublicKey().toString('base64url'), auth: randomBytes(16).toString('base64url') } }
  126 |   expect((await page.request.post('/v1/notify/push-subscriptions', { data: subscription })).status()).toBe(204)
  127 |   expect((await page.request.put('/v1/notify/telegram', { data: { botToken: '123456:acceptance-fixture', chatId: '123' } })).ok()).toBeTruthy()
  128 |   await fixture(page)
  129 |   const title = `一分钟后提醒-${Date.now()}`
  130 |   const due = new Date(Date.now() + 60000).toISOString()
  131 |   await fixture(page, [reply(title, [{ op: 'create_task', title, due, remind: 'at' }])])
```