# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: golden.spec.ts >> G5 失败恢复：副手首请求报错，原地重试成功
- Location: tests/golden.spec.ts:97:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('.activity')
Expected substring: "已加入 3 个子任务"
Received string:    "副手没做成：出了点问题重试刚刚你创建刚刚你创建刚刚"
Timeout: 20000ms

Call log:
  - Expect "toContainText" locator('.activity') with timeout 20000ms
  - waiting for locator('.activity')
    44 × locator resolved to <ol class="record activity">…</ol>
       - unexpected value "副手没做成：出了点问题重试刚刚你创建刚刚你创建刚刚"

```

```yaml
- list:
  - listitem:
    - text: 副手 没做成：出了点问题
    - button "重试"
    - text: 刚刚
  - listitem: 你 创建 刚刚
  - listitem: 你 创建 刚刚
```

# Test source

```ts
  5   | test.use({ timezoneId: 'Asia/Shanghai', viewport: { width: 1440, height: 1000 } })
  6   | test.beforeEach(async ({ page }) => {
  7   |   await login(page)
  8   |   await command(page, { type: 'updateSettings', patch: { timezone: 'Asia/Shanghai', followUps: true } })
  9   | })
  10  | test.afterEach(async ({ page }, info) => { await evidence(page, info) })
  11  | 
  12  | const schedule = '周五下午三点和张三对方案，算在 A 项目里'
  13  | async function arrange(page: Parameters<typeof say>[0], title: string) {
  14  |   let state = await snapshot(page)
  15  |   if (!state.projects.some(p => p.name === 'A')) state = await command(page, { type: 'addProject', name: 'A' })
  16  |   const due = nextWeekday(5, 15)
  17  |   await fixture(page, [reply(schedule, [{ op: 'create_task', title, due, project: 'P1', remind: null }])])
  18  |   const response = await say(page, schedule)
  19  |   const task = response.state.tasks.find((t: { id: string }) => t.id === response.turn.receipts[0].thingId)
  20  |   expect(task).toMatchObject({ due: utc(due), projectId: state.projects.find(p => p.name === 'A')!.id })
  21  |   expect(task.triggers[0]).toMatchObject({ offset: '-30m', nextAt: utc(due.replace('15:00', '14:30')) })
  22  |   return task
  23  | }
  24  | 
  25  | test('G1 一句话安排：时间、项目、提醒、刷新与撤销', async ({ page }) => {
  26  |   const task = await arrange(page, `和张三对方案-${Date.now()}`)
  27  |   const receipt = page.locator('.sec-receipt').filter({ hasText: task.title })
  28  |   await expect(receipt).toContainText('15:00')
  29  |   await expect(receipt).toContainText('A 项目')
  30  |   await expect(receipt).toContainText('14:30 提醒')
  31  |   await expect(page.locator('.hall-task').filter({ hasText: task.title })).toBeVisible()
  32  |   await evidence(page, test.info(), 'arranged')
  33  |   await page.reload()
  34  |   await expect(receipt).toBeVisible()
  35  |   await expect(page.locator('.hall-task').filter({ hasText: task.title })).toBeVisible()
  36  |   await receipt.getByRole('button', { name: '撤销', exact: true }).click()
  37  |   await expect(receipt).toContainText('已撤销')
  38  |   expect((await snapshot(page)).tasks.some(t => t.id === task.id)).toBeFalsy()
  39  |   await expect(page.locator('.hall-task').filter({ hasText: task.title })).toHaveCount(0)
  40  | })
  41  | 
  42  | test('G2 边问边记：回复前连续发送，两轮都处理', async ({ page }) => {
  43  |   const title = `交电费-${Date.now()}`
  44  |   await fixture(page, [
  45  |     { ...reply('今天怎么安排比较好', [], { reply: '先处理到期事项。' }), delay: 2500 },
  46  |     reply('顺便记下明天交电费', [{ op: 'create_task', title, due: localTime(1, 9) }]),
  47  |   ])
  48  |   const first = say(page, '今天怎么安排比较好')
  49  |   await expect(page.getByText('正在想…', { exact: true })).toBeVisible()
  50  |   await expect(input(page)).toBeEnabled()
  51  |   const second = await say(page, '顺便记下明天交电费')
  52  |   await first
  53  |   await expect(page.getByText('先处理到期事项。', { exact: true })).toBeVisible()
  54  |   expect(second.turn.receipts[0].op).toBe('create_task')
  55  |   await expect(page.locator('.hall-task').filter({ hasText: title })).toBeVisible()
  56  |   await expect(input(page)).toBeEnabled()
  57  | })
  58  | 
  59  | test('G3 改安排：同一件事改到周一，提醒跟随', async ({ page }) => {
  60  |   const task = await arrange(page, `改期方案-${Date.now()}`)
  61  |   const due = nextWeekday(1, 10)
  62  |   await fixture(page, [reply('改到下周一上午十点', [{ op: 'update', ref: 'R1', set: { due } }])])
  63  |   const response = await say(page, '改到下周一上午十点')
  64  |   expect(response.turn.receipts[0].thingId).toBe(task.id)
  65  |   const changed = response.state.tasks.find((t: { id: string }) => t.id === task.id)
  66  |   expect(changed.due).toBe(utc(due))
  67  |   expect(changed.triggers[0].nextAt).toBe(utc(due.replace('10:00', '09:30')))
  68  |   expect(response.state.tasks.filter((t: { title: string }) => t.title === task.title)).toHaveLength(1)
  69  |   await page.goto(`/t/${task.id}`)
  70  |   await expect(page.locator('.info-line')).toContainText('10:00')
  71  |   await expect(page.locator('.info-line')).toContainText('09:30 提醒')
  72  | })
  73  | 
  74  | async function taskPage(page: Parameters<typeof say>[0], title: string) {
  75  |   const state = await command(page, { type: 'addTask', title })
  76  |   const task = state.tasks.find(t => t.title === title)!
  77  |   await page.goto(`/t/${task.id}`)
  78  |   return task
  79  | }
  80  | const breakdown = reply('拆成三步', [{ op: 'delegate', ref: 'THIS', kind: 'breakdown', prompt: '拆成三步' }])
  81  | 
  82  | test('G4 事项页秘书：自动加入三步、撤销、放回去', async ({ page }) => {
  83  |   const task = await taskPage(page, `准备方案-${Date.now()}`)
  84  |   await fixture(page, [breakdown])
  85  |   await say(page, '拆成三步')
  86  |   const adoption = page.locator('.activity > li').filter({ hasText: '已加入 3 个子任务' })
  87  |   await expect(adoption).toBeVisible({ timeout: 20000 })
  88  |   expect((await snapshot(page)).tasks.find(t => t.id === task.id)!.checklist).toHaveLength(3)
  89  |   await adoption.getByRole('button', { name: '撤销', exact: true }).click()
  90  |   await expect(page.getByRole('button', { name: '加入 3 个子任务', exact: true })).toBeVisible()
  91  |   expect((await snapshot(page)).tasks.find(t => t.id === task.id)!.checklist).toHaveLength(0)
  92  |   await page.getByRole('button', { name: '加入 3 个子任务', exact: true }).click()
  93  |   await expect(adoption).toBeVisible()
  94  |   expect((await snapshot(page)).tasks.find(t => t.id === task.id)!.checklist).toHaveLength(3)
  95  | })
  96  | 
  97  | test('G5 失败恢复：副手首请求报错，原地重试成功', async ({ page }) => {
  98  |   await taskPage(page, `失败恢复-${Date.now()}`)
  99  |   await fixture(page, [breakdown, { kind: 'assistant', match: '', status: 503, once: true }])
  100 |   await say(page, '拆成三步')
  101 |   const retry = page.getByRole('button', { name: '重试', exact: true })
  102 |   await expect(retry).toBeVisible({ timeout: 20000 })
  103 |   await expect(page.locator('.activity')).toContainText('没做成：')
  104 |   await retry.click()
> 105 |   await expect(page.locator('.activity')).toContainText('已加入 3 个子任务', { timeout: 20000 })
      |                                           ^ Error: expect(locator).toContainText(expected) failed
  106 |   expect((await events(page)).filter(e => e.kind === 'model' && e.role === 'assistant')).toHaveLength(2)
  107 | })
  108 | 
  109 | test('G6 提醒送达：真实等待一分钟、首页、Web Push、Telegram', async ({ page, context }) => {
  110 |   test.setTimeout(130000)
  111 |   await context.grantPermissions(['notifications'], { origin: process.env.PCAS_TEST_BASE_URL })
  112 |   await page.reload()
  113 |   test.info().annotations.push({ type: 'push-permission', description: await page.evaluate(() => Notification.permission) })
  114 |   await page.evaluate(() => navigator.serviceWorker.ready.then(r => r.active?.state))
  115 |   const key = createECDH('prime256v1'); key.generateKeys()
  116 |   const subscription = { endpoint: 'https://push.pcas.test/push', keys: { p256dh: key.getPublicKey().toString('base64url'), auth: randomBytes(16).toString('base64url') } }
  117 |   expect((await page.request.post('/v1/notify/push-subscriptions', { data: subscription })).status()).toBe(204)
  118 |   expect((await page.request.put('/v1/notify/telegram', { data: { botToken: '123456:acceptance-fixture', chatId: '123' } })).ok()).toBeTruthy()
  119 |   await fixture(page)
  120 |   const title = `一分钟后提醒-${Date.now()}`
  121 |   const due = new Date(Date.now() + 60000).toISOString()
  122 |   await fixture(page, [reply(title, [{ op: 'create_task', title, due, remind: 'at' }])])
  123 |   const response = await say(page, title)
  124 |   expect(response.turn.receipts[0]).toMatchObject({ status: 'done', op: 'create_task' })
  125 |   await page.goto('/')
  126 |   await expect(page.locator('.hall-rang-group').filter({ hasText: title })).toBeVisible({ timeout: 105000 })
  127 |   await expect.poll(async () => (await events(page)).some(e => e.kind === 'sendMessage' && String(e.text).includes(title)), { timeout: 25000 }).toBeTruthy()
  128 |   await expect.poll(async () => (await events(page)).some(e => e.kind === 'push' && Number(e.bytes) > 0 && e.encoding === 'aes128gcm' && e.authorization === true), { timeout: 25000 }).toBeTruthy()
  129 |   await test.info().attach('delivery', { body: JSON.stringify((await events(page)).filter(e => e.kind !== 'model'), null, 2), contentType: 'application/json' })
  130 | })
  131 | 
  132 | test('G7 Telegram 对话：入站文字、首页、回执按钮和撤销回调', async ({ page }) => {
  133 |   test.setTimeout(40000)
  134 |   expect((await page.request.put('/v1/notify/telegram', { data: { botToken: '123456:acceptance-fixture', chatId: '123' } })).ok()).toBeTruthy()
  135 |   const title = `去银行-${Date.now()}`
  136 |   const id = Date.now()
  137 |   await fixture(page, [reply('后天上午九点去银行', [{ op: 'create_task', title, due: localTime(2, 9) }])], [{ update_id: id, message: { message_id: id, chat: { id: 123, type: 'private' }, text: '后天上午九点去银行' } }])
  138 |   await expect(page.locator('.hall-task').filter({ hasText: title })).toBeVisible({ timeout: 20000 })
  139 |   await expect.poll(async () => (await events(page)).some(e => e.kind === 'sendMessage' && e.reply_markup), { timeout: 15000 }).toBeTruthy()
  140 |   const sent = (await events(page)).find(e => e.kind === 'sendMessage' && e.reply_markup)!
  141 |   expect(String(sent.text)).toContain(title)
  142 |   const markup = sent.reply_markup as { inline_keyboard: { text: string; callback_data: string }[][] }
  143 |   const undo = markup.inline_keyboard.flat().find(b => b.text.includes('撤销'))!
  144 |   expect(undo).toBeTruthy()
  145 |   const messageId = Number(sent.messageId)
  146 |   expect(Number.isSafeInteger(messageId)).toBeTruthy()
  147 |   expect(messageId).toBeGreaterThan(0)
  148 |   await fixture(page, [], [{ update_id: id + 1, callback_query: { id: `undo-${id}`, from: { id: 123 }, message: { message_id: messageId, chat: { id: 123, type: 'private' } }, data: undo.callback_data } }])
  149 |   await expect(page.locator('.hall-task').filter({ hasText: title })).toHaveCount(0, { timeout: 15000 })
  150 |   expect((await snapshot(page)).tasks.some(t => t.title === title)).toBeFalsy()
  151 |   await expect.poll(async () => (await events(page)).some(e => e.kind === 'answerCallbackQuery')).toBeTruthy()
  152 | })
  153 | 
  154 | test('G8 完成即撤销：首页勾选、toast、回到原位', async ({ page }) => {
  155 |   const title = `完成即撤销-${Date.now()}`
  156 |   const task = await taskPage(page, title)
  157 |   await command(page, { type: 'updateTask', id: task.id, patch: { due: new Date(Date.now() + 3600000).toISOString() } })
  158 |   await page.goto('/')
  159 |   const row = page.locator('.hall-task').filter({ hasText: title })
  160 |   await row.getByRole('button', { name: `做完了：${title}` }).click()
  161 |   await expect(page.locator('.toast')).toContainText('做完了')
  162 |   expect((await snapshot(page)).tasks.find(t => t.id === task.id)!.status).toBe('done')
  163 |   await page.locator('.toast').getByRole('button', { name: '撤销', exact: true }).click()
  164 |   await expect(row).toBeVisible()
  165 |   expect((await snapshot(page)).tasks.find(t => t.id === task.id)!.status).toBe('todo')
  166 | })
  167 | 
  168 | test('G9 不丢话：模型真实超时后收到保存回执并能查原话', async ({ page }) => {
  169 |   test.setTimeout(115000)
  170 |   const text = `超时也要保留这句原话-${Date.now()}`
  171 |   await fixture(page, [{ kind: 'secretary', match: text, delay: 95000, content: '{}' }])
  172 |   await input(page).fill(text)
  173 |   await input(page).press('Enter')
  174 |   await expect(page.getByText('已记下原话；模型响应超时，稍后会自动整理', { exact: true })).toBeVisible({ timeout: 105000 })
  175 |   await evidence(page, test.info(), 'captured')
  176 |   const state = await snapshot(page)
  177 |   const sourceID = state.candidates.find(c => c.text === text)!.source.sourceId
  178 |   const index = state.sources.findIndex(s => s.id === sourceID)
  179 |   expect(index).toBeGreaterThanOrEqual(0)
  180 |   await page.goto('/library')
  181 |   await page.getByRole('radio', { name: /^来源/ }).click()
  182 |   await page.locator('.source-card').nth(index).click()
  183 |   await page.getByText('展开原文', { exact: true }).click()
  184 |   await expect(page.getByText('展开原文', { exact: true }).locator('..').locator('pre')).toHaveText(text)
  185 | })
  186 | 
  187 | test('F7 连续撤销：改期、新建依次撤销，刷新保持已撤销', async ({ page }) => {
  188 |   const task = await arrange(page, `连续撤销-${Date.now()}`)
  189 |   const created = page.locator('.sec-receipt').filter({ hasText: task.title }).first()
  190 |   const due = nextWeekday(1, 16)
  191 |   await fixture(page, [reply('改到下周一四点', [{ op: 'update', ref: 'R1', set: { due } }])])
  192 |   const response = await say(page, '改到下周一四点')
  193 |   expect(response.turn.receipts[0].thingId).toBe(task.id)
  194 |   const updated = page.locator('.sec-receipt').filter({ hasText: task.title }).last()
  195 |   await updated.getByRole('button', { name: '撤销', exact: true }).click()
  196 |   await expect(updated).toContainText('已撤销')
  197 |   expect((await snapshot(page)).tasks.find(t => t.id === task.id)).toMatchObject({ due: task.due, triggers: task.triggers })
  198 |   await created.getByRole('button', { name: '撤销', exact: true }).click()
  199 |   await expect(created).toContainText('已撤销')
  200 |   expect((await snapshot(page)).tasks.some(t => t.id === task.id)).toBeFalsy()
  201 |   await expect(page.locator('.hall-task').filter({ hasText: task.title })).toHaveCount(0)
  202 |   await page.reload()
  203 |   const receipts = page.locator('.sec-receipt').filter({ hasText: task.title })
  204 |   await expect(receipts).toHaveCount(2)
  205 |   await expect(receipts.nth(0)).toContainText('已撤销')
```