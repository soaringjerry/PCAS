# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: golden.spec.ts >> F7 连续撤销：改期、新建依次撤销，刷新保持已撤销
- Location: tests/golden.spec.ts:187:1

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  locator('.sec-receipt').filter({ hasText: '连续撤销-1790866924075' })
Expected: 2
Received: 1
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" locator('.sec-receipt').filter({ hasText: '连续撤销-1790866924075' }) with timeout 5000ms
  - waiting for locator('.sec-receipt').filter({ hasText: '连续撤销-1790866924075' })
    2 × locator resolved to 0 elements
      - unexpected value "0"
    12 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [ref=f1e3]:
  - banner [ref=f1e4]:
    - link "回到大厅" [ref=f1e5] [cursor=pointer]:
      - /url: /
      - text: PCAS
    - navigation "导航" [ref=f1e6]:
      - button "搜索" [ref=f1e7] [cursor=pointer]:
        - generic [ref=f1e12]: Ctrl K
      - link "资料库" [ref=f1e13] [cursor=pointer]:
        - /url: /library
      - link "设置" [ref=f1e17] [cursor=pointer]:
        - /url: /settings
  - main [ref=f1e22]:
    - generic [ref=f1e23]:
      - region [ref=f1e24]:
        - generic [ref=f1e25]:
          - heading "今天" [level=1] [ref=f1e26]
          - generic [ref=f1e27]: 10月1日星期四
        - generic [ref=f1e28]:
          - generic [ref=f1e29]:
            - heading "到点了" [level=2] [ref=f1e30]
            - generic [ref=f1e31]:
              - button "做完了：一分钟后提醒-1790866726166" [ref=f1e32] [cursor=pointer]
              - link "一分钟后提醒-1790866726166 今天 22:59 到点" [ref=f1e34] [cursor=pointer]:
                - /url: /t/27022bdd-6098-40c5-958d-04035ce5e232
                - generic [ref=f1e35]: 一分钟后提醒-1790866726166
                - generic [ref=f1e36]: 今天 22:59 到点
              - button "关掉提醒：一分钟后提醒-1790866726166" [ref=f1e37] [cursor=pointer]
          - generic [ref=f1e41]:
            - heading "按时间" [level=2] [ref=f1e42]
            - separator "现在 23:02" [ref=f1e43]:
              - generic [ref=f1e44]: 现在
              - generic [ref=f1e46]: 23:02
            - paragraph [ref=f1e47]: 今天没有定了时间的事。
          - generic [ref=f1e48]:
            - heading "这几天" [level=2] [ref=f1e49]
            - generic [ref=f1e50]:
              - button "做完了：完成即撤销-1790866830214" [ref=f1e51] [cursor=pointer]
              - link "完成即撤销-1790866830214 明天截止" [ref=f1e53] [cursor=pointer]:
                - /url: /t/6d114b39-5b4a-452d-9483-7ff9b54a1639
                - generic [ref=f1e54]: 完成即撤销-1790866830214
                - generic [ref=f1e55]: 明天截止
            - generic [ref=f1e56]:
              - button "做完了：交电费-1790866692449" [ref=f1e57] [cursor=pointer]
              - link "交电费-1790866692449 明天截止" [ref=f1e59] [cursor=pointer]:
                - /url: /t/ac7f939b-1a68-4851-956e-fc6dd6a07318
                - generic [ref=f1e60]: 交电费-1790866692449
                - generic [ref=f1e61]: 明天截止
          - paragraph [ref=f1e62]: 更远的事临近时会自己进来。
      - generic [ref=f1e63]:
        - region "秘书" [ref=f1e64]:
          - generic [ref=f1e65]:
            - button "结束这次对话" [ref=f1e66] [cursor=pointer]
            - list [ref=f1e70]:
              - listitem [ref=f1e71]:
                - paragraph [ref=f1e72]: 周五下午三点和张三对方案，算在 A 项目里
                - paragraph [ref=f1e73]: 安排好了。
                - list [ref=f1e74]:
                  - listitem [ref=f1e75]:
                    - generic "已建：明天 15:00 连续撤销-1790866924075 · A 项目 · 14:30 提醒" [ref=f1e80]
                    - generic [ref=f1e81]: 已撤销
              - listitem [ref=f1e82]:
                - paragraph [ref=f1e83]: 改到下周一四点
                - paragraph [ref=f1e84]: （这条回答依据的记忆已变更）
                - list [ref=f1e85]:
                  - listitem [ref=f1e86]:
                    - generic "这项操作已完成；相关回答内容已隐藏" [ref=f1e91]
                    - generic [ref=f1e92]: 已撤销
          - generic [ref=f1e94]:
            - textbox "跟秘书说" [ref=f1e95]:
              - /placeholder: 说一句：记事、问事、改安排都行
            - button "发送" [disabled] [ref=f1e96]
        - region "你不在的时候" [ref=f1e99]:
          - button "你不在的时候：3 件 有新的" [ref=f1e100] [cursor=pointer]:
            - generic [ref=f1e101]: 你不在的时候：3 件
            - generic "有新的" [ref=f1e102]
      - generic [ref=f1e106]:
        - region [ref=f1e107]:
          - heading "项目" [level=2] [ref=f1e109]
          - list [ref=f1e110]:
            - listitem [ref=f1e111] [cursor=pointer]:
              - generic [ref=f1e112]:
                - text: A
                - generic "有新进展" [ref=f1e113]
              - generic [ref=f1e114]: 进行中 · 1 件在做
              - generic [ref=f1e115]: 还没有进展记录
              - generic [ref=f1e116]: 下一步：改期方案-1790866695707
        - region [ref=f1e117]:
          - heading "想法" [level=2] [ref=f1e119]
          - paragraph [ref=f1e120]: 还没有想法。在导办台随口说一句「要不……」就会记到这里。
```

# Test source

```ts
  104 |   await retry.click()
  105 |   await expect(page.locator('.activity')).toContainText('已加入 3 个子任务', { timeout: 20000 })
  106 |   expect((await events(page)).filter(e => e.kind === 'model' && e.role === 'assistant')).toHaveLength(2)
  107 | })
  108 | 
  109 | test('G6 提醒送达：真实等待一分钟、首页、Web Push、Telegram', async ({ page, context }) => {
  110 |   test.setTimeout(130000)
  111 |   await context.grantPermissions(['notifications'], { origin: process.env.PCAS_TEST_BASE_URL })
  112 |   await page.reload()
  113 |   test.info().annotations.push({ type: 'push-permission', description: await page.evaluate(() => Notification.permission) })
  114 |   await page.evaluate(() => navigator.serviceWorker.ready.then(r => r.active?.state))
  115 |   const key = createECDH('prime256v1'); key.generateKeys()
  116 |   const subscription = { endpoint: 'https://push.pcas.test/push', keys: { p256dh: key.getPublicKey().toString('base64url'), auth: randomBytes(16).toString('base64url') } }
  117 |   expect((await page.request.post('/v1/notify/push-subscriptions', { data: subscription })).status()).toBe(204)
  118 |   expect((await page.request.put('/v1/notify/telegram', { data: { botToken: '123456:acceptance-fixture', chatId: '123' } })).ok()).toBeTruthy()
  119 |   await fixture(page)
  120 |   const title = `一分钟后提醒-${Date.now()}`
  121 |   const due = new Date(Date.now() + 60000).toISOString()
  122 |   await fixture(page, [reply(title, [{ op: 'create_task', title, due, remind: 'at' }])])
  123 |   const response = await say(page, title)
  124 |   expect(response.turn.receipts[0]).toMatchObject({ status: 'done', op: 'create_task' })
  125 |   await page.goto('/')
  126 |   await expect(page.locator('.hall-rang-group').filter({ hasText: title })).toBeVisible({ timeout: 105000 })
  127 |   await expect.poll(async () => (await events(page)).some(e => e.kind === 'sendMessage' && String(e.text).includes(title)), { timeout: 25000 }).toBeTruthy()
  128 |   await expect.poll(async () => (await events(page)).some(e => e.kind === 'push' && Number(e.bytes) > 0 && e.encoding === 'aes128gcm' && e.authorization === true), { timeout: 25000 }).toBeTruthy()
  129 |   await test.info().attach('delivery', { body: JSON.stringify((await events(page)).filter(e => e.kind !== 'model'), null, 2), contentType: 'application/json' })
  130 | })
  131 | 
  132 | test('G7 Telegram 对话：入站文字、首页、回执按钮和撤销回调', async ({ page }) => {
  133 |   test.setTimeout(40000)
  134 |   expect((await page.request.put('/v1/notify/telegram', { data: { botToken: '123456:acceptance-fixture', chatId: '123' } })).ok()).toBeTruthy()
  135 |   const title = `去银行-${Date.now()}`
  136 |   const id = Date.now()
  137 |   await fixture(page, [reply('后天上午九点去银行', [{ op: 'create_task', title, due: localTime(2, 9) }])], [{ update_id: id, message: { message_id: id, chat: { id: 123, type: 'private' }, text: '后天上午九点去银行' } }])
  138 |   await expect(page.locator('.hall-task').filter({ hasText: title })).toBeVisible({ timeout: 20000 })
  139 |   await expect.poll(async () => (await events(page)).some(e => e.kind === 'sendMessage' && e.reply_markup), { timeout: 15000 }).toBeTruthy()
  140 |   const sent = (await events(page)).find(e => e.kind === 'sendMessage' && e.reply_markup)!
  141 |   expect(String(sent.text)).toContain(title)
  142 |   const markup = sent.reply_markup as { inline_keyboard: { text: string; callback_data: string }[][] }
  143 |   const undo = markup.inline_keyboard.flat().find(b => b.text.includes('撤销'))!
  144 |   expect(undo).toBeTruthy()
  145 |   const messageId = Number(sent.messageId)
  146 |   expect(Number.isSafeInteger(messageId)).toBeTruthy()
  147 |   expect(messageId).toBeGreaterThan(0)
  148 |   await fixture(page, [], [{ update_id: id + 1, callback_query: { id: `undo-${id}`, from: { id: 123 }, message: { message_id: messageId, chat: { id: 123, type: 'private' } }, data: undo.callback_data } }])
  149 |   await expect(page.locator('.hall-task').filter({ hasText: title })).toHaveCount(0, { timeout: 15000 })
  150 |   expect((await snapshot(page)).tasks.some(t => t.title === title)).toBeFalsy()
  151 |   await expect.poll(async () => (await events(page)).some(e => e.kind === 'answerCallbackQuery')).toBeTruthy()
  152 | })
  153 | 
  154 | test('G8 完成即撤销：首页勾选、toast、回到原位', async ({ page }) => {
  155 |   const title = `完成即撤销-${Date.now()}`
  156 |   const task = await taskPage(page, title)
  157 |   await command(page, { type: 'updateTask', id: task.id, patch: { due: new Date(Date.now() + 3600000).toISOString() } })
  158 |   await page.goto('/')
  159 |   const row = page.locator('.hall-task').filter({ hasText: title })
  160 |   await row.getByRole('button', { name: `做完了：${title}` }).click()
  161 |   await expect(page.locator('.toast')).toContainText('做完了')
  162 |   expect((await snapshot(page)).tasks.find(t => t.id === task.id)!.status).toBe('done')
  163 |   await page.locator('.toast').getByRole('button', { name: '撤销', exact: true }).click()
  164 |   await expect(row).toBeVisible()
  165 |   expect((await snapshot(page)).tasks.find(t => t.id === task.id)!.status).toBe('todo')
  166 | })
  167 | 
  168 | test('G9 不丢话：模型真实超时后收到保存回执并能查原话', async ({ page }) => {
  169 |   test.setTimeout(115000)
  170 |   const text = `超时也要保留这句原话-${Date.now()}`
  171 |   await fixture(page, [{ kind: 'secretary', match: text, delay: 95000, content: '{}' }])
  172 |   await input(page).fill(text)
  173 |   await input(page).press('Enter')
  174 |   await expect(page.getByText('已记下原话；模型响应超时，稍后会自动整理', { exact: true })).toBeVisible({ timeout: 105000 })
  175 |   await evidence(page, test.info(), 'captured')
  176 |   const state = await snapshot(page)
  177 |   const sourceID = state.candidates.find(c => c.text === text)!.source.sourceId
  178 |   const index = state.sources.findIndex(s => s.id === sourceID)
  179 |   expect(index).toBeGreaterThanOrEqual(0)
  180 |   await page.goto('/library')
  181 |   await page.getByRole('radio', { name: /^来源/ }).click()
  182 |   await page.locator('.source-card').nth(index).click()
  183 |   await page.getByText('展开原文', { exact: true }).click()
  184 |   await expect(page.getByText('展开原文', { exact: true }).locator('..').locator('pre')).toHaveText(text)
  185 | })
  186 | 
  187 | test('F7 连续撤销：改期、新建依次撤销，刷新保持已撤销', async ({ page }) => {
  188 |   const task = await arrange(page, `连续撤销-${Date.now()}`)
  189 |   const created = page.locator('.sec-receipt').filter({ hasText: task.title }).first()
  190 |   const due = nextWeekday(1, 16)
  191 |   await fixture(page, [reply('改到下周一四点', [{ op: 'update', ref: 'R1', set: { due } }])])
  192 |   const response = await say(page, '改到下周一四点')
  193 |   expect(response.turn.receipts[0].thingId).toBe(task.id)
  194 |   const updated = page.locator('.sec-receipt').filter({ hasText: task.title }).last()
  195 |   await updated.getByRole('button', { name: '撤销', exact: true }).click()
  196 |   await expect(updated).toContainText('已撤销')
  197 |   expect((await snapshot(page)).tasks.find(t => t.id === task.id)).toMatchObject({ due: task.due, triggers: task.triggers })
  198 |   await created.getByRole('button', { name: '撤销', exact: true }).click()
  199 |   await expect(created).toContainText('已撤销')
  200 |   expect((await snapshot(page)).tasks.some(t => t.id === task.id)).toBeFalsy()
  201 |   await expect(page.locator('.hall-task').filter({ hasText: task.title })).toHaveCount(0)
  202 |   await page.reload()
  203 |   const receipts = page.locator('.sec-receipt').filter({ hasText: task.title })
> 204 |   await expect(receipts).toHaveCount(2)
      |                          ^ Error: expect(locator).toHaveCount(expected) failed
  205 |   await expect(receipts.nth(0)).toContainText('已撤销')
  206 |   await expect(receipts.nth(1)).toContainText('已撤销')
  207 | })
  208 | 
  209 | test('F7 顺序冲突：改标题后撤销新建返回 newer_action', async ({ page }) => {
  210 |   const task = await arrange(page, `撤销冲突-${Date.now()}`)
  211 |   await command(page, { type: 'renameThing', id: task.id, title: `${task.title}-用户修改` })
  212 |   const receipt = page.locator('.sec-receipt').filter({ hasText: task.title })
  213 |   const response = page.waitForResponse(r => r.url().endsWith('/v1/workspace/commands') && r.request().postDataJSON()?.type === 'undoAction')
  214 |   await receipt.getByRole('button', { name: '撤销', exact: true }).click()
  215 |   const conflict = await response
  216 |   expect(conflict.status()).toBe(409)
  217 |   expect(await conflict.json()).toEqual({ error: 'newer_action' })
  218 |   await expect(receipt).toContainText('后面还有改动，请先撤销它')
  219 |   expect((await snapshot(page)).tasks.find(t => t.id === task.id)?.title).toBe(`${task.title}-用户修改`)
  220 | })
  221 | 
  222 | test('F7 采纳链：撤销副手采纳后可以撤销更早的改标题', async ({ page }) => {
  223 |   const original = `采纳前-${Date.now()}`
  224 |   const task = await taskPage(page, original)
  225 |   await fixture(page, [reply('改名为准备方案', [{ op: 'update', ref: 'THIS', set: { title: `${original}-准备方案` } }])])
  226 |   await say(page, '改名为准备方案')
  227 |   await fixture(page, [breakdown])
  228 |   await say(page, '拆成三步')
  229 |   const adoption = page.locator('.activity > li').filter({ hasText: '已加入 3 个子任务' })
  230 |   await expect(adoption).toBeVisible({ timeout: 20000 })
  231 |   await adoption.getByRole('button', { name: '撤销', exact: true }).click()
  232 |   await expect(page.getByRole('button', { name: '加入 3 个子任务', exact: true })).toBeVisible()
  233 |   expect((await snapshot(page)).tasks.find(t => t.id === task.id)!.checklist).toHaveLength(0)
  234 |   await page.getByRole('button', { name: /展开对话/ }).click()
  235 |   const earlier = page.locator('.sec-turn').filter({ hasText: '改名为准备方案' }).locator('.sec-receipt')
  236 |   await earlier.getByRole('button', { name: '撤销', exact: true }).click()
  237 |   await expect(earlier).toContainText('已撤销')
  238 |   expect((await snapshot(page)).tasks.find(t => t.id === task.id)?.title).toBe(original)
  239 | })
  240 | 
```