# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: phase2_manual_backend.spec.ts >> real_revoke_clear_refuse_regenerate_submit
- Location: tests/phase2_manual_backend.spec.ts:186:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 6
+ Received  + 0

  Object {
-   "channel": "",
-   "model": "",
-   "principal_id": "",
-   "protocol": "",
    "provider": "golden",
-   "role": "",
-   "route_fingerprint": "",
  }
```

# Page snapshot

```yaml
- generic [ref=f1e2]:
  - generic [ref=f1e3]:
    - banner [ref=f1e4]:
      - link "回到大厅" [ref=f1e5] [cursor=pointer]:
        - /url: /
        - text: PCAS
      - generic [aria-hidden] [ref=f1e6]: /
      - generic [ref=f1e7]: 独立手动交接-b093a4c2-ee78-4bce-8532-bd668ed6460b
      - navigation "导航" [ref=f1e8]:
        - button "搜索" [ref=f1e9] [cursor=pointer]:
          - generic [ref=f1e14]: Ctrl K
        - link "资料库" [ref=f1e15] [cursor=pointer]:
          - /url: /library
        - link "设置" [ref=f1e19] [cursor=pointer]:
          - /url: /settings
    - main [ref=f1e24]:
      - generic [ref=f1e25]:
        - link "大厅" [ref=f1e27] [cursor=pointer]:
          - /url: /
        - generic [ref=f1e30]:
          - button "做完了" [ref=f1e31] [cursor=pointer]
          - textbox "标题" [ref=f1e32]: 独立手动交接-b093a4c2-ee78-4bce-8532-bd668ed6460b
          - button [aria-hidden] [ref=f1e33] [cursor=pointer]
        - group "这件事的情况，点一项就跟秘书说怎么改" [ref=f1e37]:
          - button "待办" [ref=f1e38] [cursor=pointer]
          - button "定个截止时间" [ref=f1e39] [cursor=pointer]
          - button "加个提醒" [ref=f1e40] [cursor=pointer]
          - button "归到项目" [ref=f1e41] [cursor=pointer]
        - textbox "说明" [ref=f1e42]:
          - /placeholder: 加点说明（点这里直接写）
          - text: OWNER 合成独立说明 cobalt-602，继续保留这段原文。
        - generic [ref=f1e43]:
          - generic [ref=f1e44]: 子任务
          - textbox "加一步" [ref=f1e49]
        - button "新建文档" [ref=f1e51] [cursor=pointer]
        - generic [ref=f1e53]:
          - generic [ref=f1e54]: 动态
          - button "手动转交" [ref=f1e56] [cursor=pointer]
          - list [ref=f1e57]:
            - listitem [ref=f1e58]:
              - generic [ref=f1e59]:
                - generic "手动交接" [ref=f1e60]: 副手
                - generic [ref=f1e61]: 等你转交：根据合成海棠交接资料-b093a4c2-ee78-4bce-8532-bd668ed6460b和这件事的独立说明，给出一段建议。
                - button "不转交了" [ref=f1e62] [cursor=pointer]
                - generic [ref=f1e66]: 刚刚
              - generic [ref=f1e67]:
                - paragraph [ref=f1e68]: 把内容复制给验收假模型，再将回答贴回。PCAS 无法确认对方是否收到。
                - generic [ref=f1e69]:
                  - button "复制给它的内容" [ref=f1e70] [cursor=pointer]
                  - button "预览交接内容" [ref=f1e74] [cursor=pointer]
                - button "换接收者，建立新请求" [ref=f1e76] [cursor=pointer]
                - textbox "贴回回答" [ref=f1e77]:
                  - /placeholder: 把它的回答贴在这里
                - button "保存并加入这件事" [disabled] [ref=f1e79]
            - listitem [ref=f1e80]:
              - generic [ref=f1e81]:
                - generic "手动交接" [ref=f1e82]: 副手
                - generic [ref=f1e83]: 等你转交：根据合成海棠交接资料-b093a4c2-ee78-4bce-8532-bd668ed6460b和这件事的独立说明，给出一段建议。
                - button "不转交了" [ref=f1e84] [cursor=pointer]
                - generic [ref=f1e88]: 刚刚
              - generic [ref=f1e89]:
                - paragraph [ref=f1e90]: 把内容复制给验收假模型，再将回答贴回。PCAS 无法确认对方是否收到。
                - alert [ref=f1e91]: 资料、授权或接收者已经变化，请重新生成交接内容。
                - generic [ref=f1e92]:
                  - button "复制给它的内容" [disabled] [ref=f1e93]
                  - button "预览交接内容" [disabled] [ref=f1e97] [cursor=pointer]
                - button "向原接收者重新生成" [ref=f1e98] [cursor=pointer]
                - button "换接收者，建立新请求" [ref=f1e100] [cursor=pointer]
                - textbox "贴回回答" [ref=f1e101]:
                  - /placeholder: 把它的回答贴在这里
                  - text: 这份旧回答不得保存
                - button "保存并加入这件事" [disabled] [ref=f1e103]
            - listitem [ref=f1e104]:
              - generic [ref=f1e105]:
                - generic [ref=f1e106]: 你
                - generic [ref=f1e107]: 更新说明
                - generic [ref=f1e108]: 刚刚
            - listitem [ref=f1e109]:
              - generic [ref=f1e110]:
                - generic [ref=f1e111]: 你
                - generic [ref=f1e112]: 创建
                - generic [ref=f1e113]: 刚刚
            - listitem [ref=f1e114]:
              - generic [ref=f1e115]:
                - generic [ref=f1e116]: 你
                - generic [ref=f1e117]: 创建
                - generic [ref=f1e118]: 刚刚
        - region "秘书" [ref=f1e119]:
          - generic [ref=f1e121]:
            - textbox "跟秘书说" [ref=f1e122]:
              - /placeholder: 关于这件事，说一句
            - button "发送" [disabled] [ref=f1e123]
  - status [ref=f1e126]: 已建立同一接收者的新请求
```

# Test source

```ts
  123 |   return run
  124 | }
  125 | 
  126 | function assertPackage(pkg: Package, run: Run, source: SourceRef, marker: string, allowed: boolean) {
  127 |   expect(pkg.run_id).toBe(run.id)
  128 |   expect(pkg.attempt.id).toMatch(/^[a-f0-9-]{36}$/)
  129 |   expect(pkg.attempt.delivered_at).toBeTruthy()
  130 |   expect(pkg.attempt.external_receipt).toBe('unknown')
  131 |   expect(pkg.attempt.manifest.recipient).toEqual(run.contextTask!.recipient)
  132 |   expect(pkg.package).toContain(ownerText)
  133 |   expect(pkg.package.includes(marker)).toBe(allowed)
  134 |   expect(pkg.attempt.manifest.input.some(input => input.ref.id === source.id && input.ref.version === source.version && input.ref.kind === source.kind)).toBe(allowed)
  135 |   expect(run.brief).not.toContain(marker)
  136 | }
  137 | 
  138 | async function obtain(page: Page, row: Locator, run: Run, copy: boolean) {
  139 |   const responsePromise = page.waitForResponse(response => new URL(response.url()).pathname === `/v1/workspace/runs/${run.id}/package` && response.request().method() === 'GET')
  140 |   await row.getByRole('button', { name: copy ? '复制给它的内容' : '预览交接内容', exact: true }).click()
  141 |   const response = await responsePromise
  142 |   expect(response.status()).toBe(200)
  143 |   const pkg = await response.json() as Package
  144 |   if (copy) {
  145 |     await expect(row.getByRole('status')).toContainText('已复制，可以粘贴给')
  146 |     expect(await page.evaluate(() => navigator.clipboard.readText())).toBe(pkg.package)
  147 |   } else await expect(row.locator('pre.act-brief')).toHaveText(pkg.package)
  148 |   await expect(row).toContainText('PCAS 无法确认对方是否收到')
  149 |   return pkg
  150 | }
  151 | 
  152 | async function submit(page: Page, row: Locator, run: Run, text: string) {
  153 |   await row.getByRole('textbox', { name: '贴回回答' }).fill(text)
  154 |   const responsePromise = page.waitForResponse(response => new URL(response.url()).pathname === '/v1/workspace/commands' && response.request().postDataJSON()?.type === 'pasteRunResult' && response.request().postDataJSON()?.id === run.id)
  155 |   await row.getByRole('button', { name: '保存并加入这件事', exact: true }).click()
  156 |   const response = await responsePromise
  157 |   expect(response.status()).toBe(200)
  158 |   expect(response.request().postDataJSON()).toMatchObject({ type: 'pasteRunResult', id: run.id, output: text })
  159 |   const state = await snapshot(page)
  160 |   expect(state.runs.find(candidate => candidate.id === run.id)).toMatchObject({ status: 'done', output: text, adopted: { auto: true, as: 'doc' } })
  161 |   expect(state.docs.filter(doc => doc.runId === run.id)).toHaveLength(1)
  162 |   expect(state.docs.find(doc => doc.runId === run.id)!.body).toBe(text)
  163 |   expect(state.tasks.find(task => task.id === run.thingId)!.notes).toBe(ownerText)
  164 |   await expect(page.getByText(ownerText, { exact: true })).toBeVisible()
  165 |   return state
  166 | }
  167 | 
  168 | test('real_target_package_clipboard_submit', async ({ page }, info) => {
  169 |   const http = observeHTTP(page)
  170 |   try {
  171 |     const data = await setup(page)
  172 |     const run = await createThroughUI(page, data.taskId, data.prompt)
  173 |     const row = runRow(page, data.prompt)
  174 |     const preview = await obtain(page, row, run, false)
  175 |     assertPackage(preview, run, data.source, data.marker, true)
  176 |     const copied = await obtain(page, row, run, true)
  177 |     assertPackage(copied, run, data.source, data.marker, true)
  178 |     expect(copied.attempt.id).not.toBe(preview.attempt.id)
  179 |     await submit(page, row, run, '合成贴回回答：请保留独立原文，按一个普通步骤继续。')
  180 |     expect((await events(page)).filter(event => event.kind === 'model' && event.role === 'assistant')).toEqual([])
  181 |     await info.attach('two-real-packages', { body: JSON.stringify({ syntheticData: data, preview, copied, originalRun: run }, null, 2), contentType: 'application/json' })
  182 |     await evidence(page, info, 'manual-real-completed')
  183 |   } finally { await http.attach(info) }
  184 | })
  185 | 
  186 | test('real_revoke_clear_refuse_regenerate_submit', async ({ page }, info) => {
  187 |   const http = observeHTTP(page)
  188 |   try {
  189 |     const data = await setup(page)
  190 |     const run = await createThroughUI(page, data.taskId, data.prompt)
  191 |     await expect(handoffRows(page, data.prompt)).toHaveCount(1)
  192 |     const oldRow = handoffRows(page, data.prompt).first()
  193 |     const lawful = await obtain(page, oldRow, run, false)
  194 |     assertPackage(lawful, run, data.source, data.marker, true)
  195 |     const clipboardSentinel = 'OWNER synthetic clipboard sentinel before revocation'
  196 |     await page.evaluate(text => navigator.clipboard.writeText(text), clipboardSentinel)
  197 |     await oldRow.getByRole('textbox', { name: '贴回回答' }).fill('这份旧回答不得保存')
  198 |     const revoke = await page.request.delete(`/v1/memory/sources/${data.source.id}/authorization`, { data: { request_id: crypto.randomUUID(), source: data.source, policy_id: data.policy.id, expected_policy_revision: data.policy.revision, recipient: data.policy.recipient, purpose: data.policy.purpose, scope: data.policy.scope, revoke: true } })
  199 |     expect(revoke.status()).toBe(200)
  200 |     expect((await revoke.json() as { authorization: Policy }).authorization).toMatchObject({ id: data.policy.id, revoked: true, revision: data.policy.revision + 1 })
  201 |     await expect(oldRow.getByRole('alert')).toContainText('资料、授权或接收者已经变化', { timeout: 12000 })
  202 |     await expect(oldRow.locator('pre.act-brief')).toHaveCount(0)
  203 |     await expect(oldRow.getByRole('button', { name: '复制给它的内容', exact: true })).toBeDisabled()
  204 |     await expect(oldRow.getByRole('button', { name: '保存并加入这件事', exact: true })).toBeDisabled()
  205 |     expect(await page.evaluate(() => navigator.clipboard.readText())).toBe(clipboardSentinel)
  206 |     const oldPackage = await page.request.get(`/v1/workspace/runs/${run.id}/package`)
  207 |     expect(oldPackage.status()).toBe(409)
  208 |     expect(await oldPackage.json()).toEqual({ error: 'version_conflict' })
  209 |     const beforeRejectedPaste = await snapshot(page)
  210 |     const oldPaste = await page.request.post('/v1/workspace/commands', { data: { type: 'pasteRunResult', id: run.id, output: '这份旧回答不得保存', requestId: crypto.randomUUID(), expectedRevision: beforeRejectedPaste.revision } })
  211 |     expect(oldPaste.status()).toBe(409)
  212 |     expect(await oldPaste.json()).toEqual({ error: 'version_conflict' })
  213 |     const refused = await snapshot(page)
  214 |     expect(refused.runs.find(candidate => candidate.id === run.id)).toMatchObject({ status: 'waiting', staleContext: true })
  215 |     expect(refused.runs.find(candidate => candidate.id === run.id)!.output).toBeFalsy()
  216 |     expect(refused.runs.find(candidate => candidate.id === run.id)!.adopted).toBeFalsy()
  217 |     expect(refused.docs.filter(doc => doc.runId === run.id)).toEqual([])
  218 |     const regeneratePromise = page.waitForResponse(response => new URL(response.url()).pathname === '/v1/workspace/commands' && response.request().postDataJSON()?.type === 'requestRun')
  219 |     await oldRow.getByRole('button', { name: '向原接收者重新生成', exact: true }).click()
  220 |     const regenerated = await regeneratePromise
  221 |     expect(regenerated.status()).toBe(200)
  222 |     const regenerationBody = regenerated.request().postDataJSON() as { id: string; manualRecipient: unknown; prompt: string; sourceRunId: string }
> 223 |     expect(regenerationBody.manualRecipient).toEqual(run.manualRecipient)
      |                                              ^ Error: expect(received).toEqual(expected) // deep equality
  224 |     expect(regenerationBody.prompt).toBe(run.prompt)
  225 |     expect(regenerationBody.id).not.toBe(run.id)
  226 |     expect(regenerationBody.sourceRunId).toBe(run.id)
  227 |     const state = await regenerated.json() as State
  228 |     const next = state.runs.find(candidate => candidate.id === regenerationBody.id)!
  229 |     expect(next).toMatchObject({ status: 'waiting', staleContext: false, prompt: run.prompt })
  230 |     expect(next.contextTask!.recipient).toEqual(run.contextTask!.recipient)
  231 |     expect(state.runs.some(candidate => candidate.id === run.id && candidate.staleContext)).toBe(true)
  232 |     await expect(handoffRows(page, data.prompt)).toHaveCount(2)
  233 |     await expect(handoffRows(page, data.prompt).filter({ has: page.getByRole('alert') })).toHaveCount(1)
  234 |     const nextRow = runRow(page, data.prompt)
  235 |     await expect(nextRow).toHaveCount(1)
  236 |     await expect(nextRow.getByRole('alert')).toHaveCount(0)
  237 |     const safePreview = await obtain(page, nextRow, next, false)
  238 |     assertPackage(safePreview, next, data.source, data.marker, false)
  239 |     const safeCopied = await obtain(page, nextRow, next, true)
  240 |     assertPackage(safeCopied, next, data.source, data.marker, false)
  241 |     expect(safeCopied.attempt.id).not.toBe(safePreview.attempt.id)
  242 |     await submit(page, nextRow, next, '合成恢复回答：仅据独立说明继续，不使用已撤资料。')
  243 |     expect((await events(page)).filter(event => event.kind === 'model' && event.role === 'assistant')).toEqual([])
  244 |     await info.attach('revoke-refuse-recover', { body: JSON.stringify({ syntheticData: data, lawful, originalRun: run, refused, next, safePreview, safeCopied }, null, 2), contentType: 'application/json' })
  245 |     await evidence(page, info, 'manual-real-recovered')
  246 |   } finally { await http.attach(info) }
  247 | })
  248 | 
```